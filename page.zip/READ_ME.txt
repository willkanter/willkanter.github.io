I built a GitHub pages website for homework 1 and added these to that website as well, but I don't have a mypage_bootstrap.html file because I changed it to index.html to make willkanter.github.io work. Also, I created a folder 'scripts' to hold my_scripts where I keep my add card function. 

Source can be found here: https://github.com/willkanter/willkanter.github.io